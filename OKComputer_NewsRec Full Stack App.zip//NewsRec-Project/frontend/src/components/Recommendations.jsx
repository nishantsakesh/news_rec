import React, { useState, useEffect } from 'react';
import ArticleCard from './ArticleCard';
import api from '../services/api';

const Recommendations = () => {
  const [recommendations, setRecommendations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchRecommendations();
  }, []);

  const fetchRecommendations = async () => {
    try {
      setLoading(true);
      setError(null);
      
      const response = await api.get('/recommendations');
      setRecommendations(response.data.recommendations);
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to fetch recommendations');
    } finally {
      setLoading(false);
    }
  };

  const handleRefresh = () => {
    fetchRecommendations();
  };

  if (loading) {
    return <div className="loading">Loading personalized recommendations...</div>;
  }

  if (error) {
    return (
      <div className="alert alert-error">
        {error}
        <button 
          onClick={fetchRecommendations} 
          className="btn btn-primary" 
          style={{ marginLeft: '1rem' }}
        >
          Retry
        </button>
      </div>
    );
  }

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem' }}>
        <h1>Recommended for You</h1>
        <button onClick={handleRefresh} className="btn btn-primary">
          Refresh Recommendations
        </button>
      </div>
      
      {recommendations.length === 0 ? (
        <div className="card">
          <h3>No recommendations available yet</h3>
          <p>Start liking articles to get personalized recommendations!</p>
          <a href="/" className="btn btn-primary">Browse Articles</a>
        </div>
      ) : (
        <>
          <p style={{ marginBottom: '1rem', color: '#666' }}>
            Showing {recommendations.length} articles recommended based on your interests
          </p>
          
          <div className="article-grid">
            {recommendations.map(article => (
              <ArticleCard
                key={article.id}
                article={article}
              />
            ))}
          </div>
        </>
      )}
    </div>
  );
};

export default Recommendations;