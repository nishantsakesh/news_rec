import React from 'react';

const ArticleCard = ({ article, onLike, isLiked = false }) => {
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  return (
    <div className="article-card">
      {article.image_url && (
        <img 
          src={article.image_url} 
          alt={article.title}
          className="article-image"
          onError={(e) => {
            e.target.style.display = 'none';
          }}
        />
      )}
      
      <div className="article-content">
        <h3 className="article-title">{article.title}</h3>
        
        {article.description && (
          <p className="article-description">{article.description}</p>
        )}
        
        <div className="article-meta">
          <span>{article.source_name || 'Unknown Source'}</span>
          <span>{formatDate(article.published_at || article.created_at)}</span>
        </div>
        
        <div className="article-actions">
          <a 
            href={article.url} 
            target="_blank" 
            rel="noopener noreferrer"
            className="btn-read"
          >
            Read More
          </a>
          
          {onLike && (
            <button
              onClick={() => onLike(article.id)}
              disabled={isLiked}
              className="btn-like"
            >
              {isLiked ? 'Liked' : 'Like'}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default ArticleCard;