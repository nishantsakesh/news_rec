import React, { useState, useEffect } from 'react';
import ArticleCard from './ArticleCard';
import api from '../services/api';

const Home = () => {
  const [articles, setArticles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [pagination, setPagination] = useState({
    page: 1,
    per_page: 20,
    total: 0,
    pages: 0
  });
  const [likedArticles, setLikedArticles] = useState(new Set());

  useEffect(() => {
    fetchArticles();
  }, [pagination.page]);

  const fetchArticles = async () => {
    try {
      setLoading(true);
      setError(null);
      
      const response = await api.get(`/news/feed?page=${pagination.page}&per_page=${pagination.per_page}`);
      
      setArticles(response.data.articles);
      setPagination(prev => ({
        ...prev,
        total: response.data.pagination.total,
        pages: response.data.pagination.pages
      }));
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to fetch articles');
    } finally {
      setLoading(false);
    }
  };

  const handleLike = async (articleId) => {
    try {
      await api.post(`/news/like/${articleId}`);
      setLikedArticles(prev => new Set([...prev, articleId]));
    } catch (err) {
      alert(err.response?.data?.error || 'Failed to like article');
    }
  };

  const handlePageChange = (newPage) => {
    setPagination(prev => ({ ...prev, page: newPage }));
    window.scrollTo(0, 0);
  };

  if (loading) {
    return <div className="loading">Loading articles...</div>;
  }

  if (error) {
    return (
      <div className="alert alert-error">
        {error}
        <button onClick={fetchArticles} className="btn btn-primary" style={{ marginLeft: '1rem' }}>
          Retry
        </button>
      </div>
    );
  }

  return (
    <div>
      <h1>Latest News</h1>
      
      {articles.length === 0 ? (
        <p>No articles available.</p>
      ) : (
        <>
          <div className="article-grid">
            {articles.map(article => (
              <ArticleCard
                key={article.id}
                article={article}
                onLike={handleLike}
                isLiked={likedArticles.has(article.id)}
              />
            ))}
          </div>
          
          {pagination.pages > 1 && (
            <div className="pagination">
              <button
                onClick={() => handlePageChange(pagination.page - 1)}
                disabled={pagination.page === 1}
              >
                Previous
              </button>
              
              <span style={{ padding: '0.5rem 1rem' }}>
                Page {pagination.page} of {pagination.pages}
              </span>
              
              <button
                onClick={() => handlePageChange(pagination.page + 1)}
                disabled={pagination.page === pagination.pages}
              >
                Next
              </button>
            </div>
          )}
        </>
      )}
    </div>
  );
};

export default Home;