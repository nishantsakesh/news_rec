import requests
from datetime import datetime, timedelta
from app.extensions import db
from app.models.article import ArticleModel
from app.services.recommender import calculate_vector
from app.config import Config

def fetch_and_store_articles():
    """
    Fetch articles from NewsAPI and store them in the database.
    Returns the number of new articles stored.
    """
    api_key = Config.NEWS_API_KEY
    if not api_key:
        raise ValueError("NEWS_API_KEY not configured")
    
    # NewsAPI endpoint configuration
    url = 'https://newsapi.org/v2/top-headlines'
    params = {
        'country': 'us',
        'pageSize': 100,  # Maximum allowed by NewsAPI
        'apiKey': api_key
    }
    
    try:
        # Make API request
        response = requests.get(url, params=params, timeout=30)
        response.raise_for_status()
        
        data = response.json()
        articles = data.get('articles', [])
        
        new_articles_count = 0
        
        for article_data in articles:
            # Skip articles with missing essential data
            if not article_data.get('title') or not article_data.get('url'):
                continue
            
            # Check if article already exists
            existing_article = ArticleModel.query.filter_by(
                url=article_data['url']
            ).first()
            
            if existing_article:
                continue
            
            # Parse published date
            published_at = None
            if article_data.get('publishedAt'):
                try:
                    published_at = datetime.fromisoformat(
                        article_data['publishedAt'].replace('Z', '+00:00')
                    )
                except ValueError:
                    pass
            
            # Create new article
            article = ArticleModel(
                title=article_data.get('title', ''),
                description=article_data.get('description', ''),
                url=article_data.get('url', ''),
                image_url=article_data.get('urlToImage', ''),
                published_at=published_at,
                source_name=article_data.get('source', {}).get('name', 'Unknown')
            )
            
            # Calculate TF-IDF vector
            text_content = f"{article.title} {article.description or ''}"
            if text_content.strip():
                article.vector = calculate_vector(text_content)
            
            db.session.add(article)
            new_articles_count += 1
        
        # Commit all new articles
        if new_articles_count > 0:
            db.session.commit()
        
        return new_articles_count
        
    except requests.RequestException as e:
        raise Exception(f"Failed to fetch from NewsAPI: {str(e)}")
    except Exception as e:
        db.session.rollback()
        raise Exception(f"Failed to store articles: {str(e)}")