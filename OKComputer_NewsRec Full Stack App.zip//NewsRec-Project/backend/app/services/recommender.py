import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from app.extensions import db
from app.models.user import UserModel
from app.models.article import ArticleModel
from app.models.like import LikeModel
import json

# Global TF-IDF vectorizer instance
tfidf_vectorizer = TfidfVectorizer(
    stop_words='english',
    max_features=1000,  # Limit features for performance
    min_df=1,
    max_df=0.8
)

def calculate_vector(text):
    """
    Calculate TF-IDF vector for given text.
    Returns the vector as a list (JSON serializable).
    """
    if not text or not text.strip():
        return None
    
    try:
        # Fit and transform the text
        vector = tfidf_vectorizer.fit_transform([text])
        # Convert to list for JSON serialization
        return vector.toarray()[0].tolist()
    except Exception:
        return None

def get_user_recommendations(user_id, num_recommendations=10):
    """
    Get personalized article recommendations for a user based on their liked articles.
    Returns a list of recommended articles.
    """
    # Check if user exists
    user = UserModel.query.get(user_id)
    if not user:
        raise ValueError("User not found")
    
    # Get articles liked by the user
    liked_articles = db.session.query(ArticleModel).join(
        LikeModel, ArticleModel.id == LikeModel.article_id
    ).filter(LikeModel.user_id == user_id).all()
    
    # If user hasn't liked any articles, return latest articles
    if not liked_articles:
        latest_articles = ArticleModel.query.order_by(
            ArticleModel.published_at.desc()
        ).limit(num_recommendations).all()
        return [article.to_dict() for article in latest_articles]
    
    # Extract vectors from liked articles
    liked_vectors = []
    for article in liked_articles:
        if article.vector:
            liked_vectors.append(np.array(article.vector))
    
    if not liked_vectors:
        # If no vectors available, return latest articles
        latest_articles = ArticleModel.query.order_by(
            ArticleModel.published_at.desc()
        ).limit(num_recommendations).all()
        return [article.to_dict() for article in latest_articles]
    
    # Create user profile vector by averaging liked article vectors
    user_profile_vector = np.mean(liked_vectors, axis=0)
    
    # Get articles not liked by the user
    liked_article_ids = [article.id for article in liked_articles]
    candidate_articles = ArticleModel.query.filter(
        ~ArticleModel.id.in_(liked_article_ids),
        ArticleModel.vector.isnot(None)
    ).all()
    
    if not candidate_articles:
        return []
    
    # Calculate similarities
    similarities = []
    for article in candidate_articles:
        if article.vector:
            article_vector = np.array(article.vector)
            similarity = cosine_similarity(
                [user_profile_vector], 
                [article_vector]
            )[0][0]
            similarities.append((article, similarity))
    
    # Sort by similarity and return top recommendations
    similarities.sort(key=lambda x: x[1], reverse=True)
    top_recommendations = similarities[:num_recommendations]
    
    # Return articles with similarity scores
    recommendations = []
    for article, similarity in top_recommendations:
        article_dict = article.to_dict()
        article_dict['similarity_score'] = float(similarity)
        recommendations.append(article_dict)
    
    return recommendations