from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from app.extensions import db
from app.models.article import ArticleModel
from app.models.like import LikeModel
from app.services.news_fetcher import fetch_and_store_articles

api_news = Blueprint('api_news', __name__)

@api_news.route('/feed', methods=['GET'])
def get_news_feed():
    try:
        # Get pagination parameters
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        
        # Validate pagination
        if page < 1 or per_page < 1 or per_page > 100:
            return jsonify({'error': 'Invalid pagination parameters'}), 400
        
        # Query articles with pagination
        articles = ArticleModel.query.order_by(ArticleModel.published_at.desc())\
            .paginate(page=page, per_page=per_page, error_out=False)
        
        return jsonify({
            'articles': [article.to_dict() for article in articles.items],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': articles.total,
                'pages': articles.pages,
                'has_next': articles.has_next,
                'has_prev': articles.has_prev
            }
        }), 200
        
    except Exception as e:
        return jsonify({'error': 'Failed to fetch news feed'}), 500

@api_news.route('/like/<int:article_id>', methods=['POST'])
@jwt_required()
def like_article(article_id):
    try:
        user_id = get_jwt_identity()
        
        # Check if article exists
        article = ArticleModel.query.get(article_id)
        if not article:
            return jsonify({'error': 'Article not found'}), 404
        
        # Check if user already liked this article
        existing_like = LikeModel.query.filter_by(
            user_id=user_id, 
            article_id=article_id
        ).first()
        
        if existing_like:
            return jsonify({'error': 'Article already liked'}), 409
        
        # Create new like
        like = LikeModel(user_id=user_id, article_id=article_id)
        db.session.add(like)
        db.session.commit()
        
        return jsonify({'message': 'Article liked successfully'}), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': 'Failed to like article'}), 500

@api_news.route('/internal/fetch-news-job', methods=['POST'])
def fetch_news_job():
    """Internal endpoint for cron job to fetch news"""
    try:
        articles_fetched = fetch_and_store_articles()
        return jsonify({
            'message': f'Successfully fetched and stored {articles_fetched} articles'
        }), 200
    except Exception as e:
        return jsonify({'error': 'Failed to fetch news'}), 500