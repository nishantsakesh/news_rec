from app.extensions import db
from datetime import datetime

class LikeModel(db.Model):
    __tablename__ = 'likes'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    article_id = db.Column(db.Integer, db.ForeignKey('articles.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Ensure user can only like an article once
    __table_args__ = (db.UniqueConstraint('user_id', 'article_id', name='unique_user_article_like'),)
    
    def to_dict(self):
        """Convert like to dictionary"""
        return {
            'id': self.id,
            'user_id': self.user_id,
            'article_id': self.article_id,
            'created_at': self.created_at.isoformat()
        }