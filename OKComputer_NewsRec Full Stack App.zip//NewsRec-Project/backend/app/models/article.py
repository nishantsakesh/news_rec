from app.extensions import db
from datetime import datetime

class ArticleModel(db.Model):
    __tablename__ = 'articles'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(500), nullable=False)
    description = db.Column(db.Text)
    url = db.Column(db.String(500), unique=True, nullable=False)
    image_url = db.Column(db.String(500))
    published_at = db.Column(db.DateTime)
    source_name = db.Column(db.String(100))
    vector = db.Column(db.JSON)  # Store TF-IDF vector as JSON
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    likes = db.relationship('LikeModel', backref='article', lazy='dynamic', cascade='all, delete-orphan')
    
    def to_dict(self):
        """Convert article to dictionary"""
        return {
            'id': self.id,
            'title': self.title,
            'description': self.description,
            'url': self.url,
            'image_url': self.image_url,
            'published_at': self.published_at.isoformat() if self.published_at else None,
            'source_name': self.source_name,
            'created_at': self.created_at.isoformat()
        }