from flask import Flask
from app.config import Config
from app.extensions import db, migrate, jwt, cors
from app.api.auth_routes import api_auth
from app.api.news_routes import api_news
from app.api.recommend_routes import api_rec

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)
    
    # Initialize extensions
    db.init_app(app)
    migrate.init_app(app, db)
    jwt.init_app(app)
    cors.init_app(app, origins=app.config.get('CORS_ORIGINS', ['*']))
    
    # Register blueprints
    app.register_blueprint(api_auth, url_prefix='/api/auth')
    app.register_blueprint(api_news, url_prefix='/api/news')
    app.register_blueprint(api_rec, url_prefix='/api')
    
    # Health check endpoint
    @app.route('/health')
    def health_check():
        return {'status': 'healthy', 'message': 'NewsRec API is running'}, 200
    
    # Error handlers
    @app.errorhandler(404)
    def not_found(error):
        return {'error': 'Resource not found'}, 404
    
    @app.errorhandler(500)
    def internal_error(error):
        return {'error': 'Internal server error'}, 500
    
    return app